#import "AAAudioPlayer.h"

@interface AANativeAudioPlayer : AAAudioPlayer

- (instancetype)initWithPath:(NSString *)path;

@end
